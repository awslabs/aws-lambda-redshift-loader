var region = 'eu-west-1';

var aws = require('aws-sdk');
var s3 = new aws.S3({
	apiVersion : '2006-03-01',
	region : region
});
var dynamoDB = new aws.DynamoDB({
	apiVersion : '2012-08-10',
	region : region
});
var sns = new aws.SNS({
	apiVersion : '2010-03-31',
	region : region
});
var jdbc = new (require('jdbc'));
var java = require('java');

// variables used for dynamo DB attributes - using variables so they can be
// globally changed in the code if needed
var batchId = 'batchId';
var lastUpdate = 'lastUpdate';
var pending = 'pending';
var error = 'error';
var entries = 'entries';
var status = 'status';
var configTable = 'LambdaRedshiftBatchLoadConfig';
var batchTable = 'LambdaRedshiftBatches';

// function which creates a string representation of now suitable for use in S3
// paths
getFormattedDate = function() {
	var date = new Date();

	var hour = date.getHours();
	hour = (hour < 10 ? "0" : "") + hour;

	var min = date.getMinutes();
	min = (min < 10 ? "0" : "") + min;

	var sec = date.getSeconds();
	sec = (sec < 10 ? "0" : "") + sec;

	var year = date.getFullYear();

	var month = date.getMonth() + 1;
	month = (month < 10 ? "0" : "") + month;

	var day = date.getDate();
	day = (day < 10 ? "0" : "") + day;

	return year + "-" + month + "-" + day + "-" + hour + ":" + min + ":" + sec;
}

function generateUUID() {
	var d = new Date().getTime();
	var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
		var r = (d + Math.random() * 16) % 16 | 0;
		d = Math.floor(d / 16);
		return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
	});
	return uuid;
}

function now() {
	return new Date().getTime() / 1000;
}

// main function for AWS Lambda
exports.handler = function(event, context) {
	// extract the s3 event details
	var bucket = event.Records[0].s3.bucket.name;
	var key = event.Records[0].s3.object.key;

	var keyComponents = key.split('/');

	var prefix = bucket + "/" + key.replace('/' + keyComponents[keyComponents.length - 1], '')

	console.log('Fetching Redshift Load Configuration for ' + prefix);

	// Get the Redshift Load Configuration
	var dynamoLookup = {
		Key : {
			's3Prefix' : {
				S : prefix
			}
		},
		TableName : configTable
	};

	var config;
	var manifestPrefix;
	var manifestName;

	/** runtime functions * */

	/* callback run when we find a configuration for load in Dynamo DB */
	foundConfig = function(err, data) {
		if (err) {
			var msg = 'Error getting Redshift Configuration for ' + prefix + ' from Dynamo DB ';
			context.done(error, msg);
		}

		if (data === undefined || data === null) {
			console.log('No Redshift Load Configuration Found for ' + prefix);

			// finish with no exception - the configuration might be for
			// another part of the S3 structure
			context.done(null, '');
		} else {
			config = data.Item;

			var filter = config.filenameFilterRegex
			if (filter) {
				if (key.match(filter.S)) {
					addFileEntry(bucket, key, processPendingBatch);
				} else {
					console.log('Object ' + key + ' excluded by filename filter \'' + filter.S + '\'');

					// scan the current batch to decide if it needs to be
					// flushed due to batch timeout
					processPendingBatch();
				}
			} else {
				// no filter, so we'll load the data
				addFileEntry(bucket, key, processPendingBatch);
			}
		}
	}

	/*
	 * function to process the current pending batch, and create a batch load
	 * process if required
	 */
	processPendingBatch = function() {
		// make the request for the current batch
		var currentBatchRequest = {
			Key : {
				batchId : {
					S : pending
				}
			},
			TableName : batchTable
		};

		dynamoDB.getItem(currentBatchRequest, function(err, data) {
			if (err) {
				console.log(err);
				context.done(error, err);
			}

			// check whether the current batch is bigger than
			// the configured
			// max, or older than configured max
			var lastUpdateTime = data.Item.lastUpdate.N;
			var pendingEntries = data.Item.entries.SS;
			if (pendingEntries.length >= config.batchSize.N || now - lastUpdateTime > config.batchTimeoutSecs) {

				// batch should be swept out by allocating a new
				// batch number,
				// showing that its in process and then
				// allocating it to a load
				// process

				// delete the pending batch
				var item = {
					Key : {
						batchId : {
							S : pending
						}
					},
					TableName : batchTable,
					ReturnValues : 'ALL_OLD'
				}

				// delete the pending batch - new batches will be written onto a
				// new pending batch entry
				dynamoDB.deleteItem(item, function(err, data) {
					if (err) {
						console.log(err);
						context.done(error, err);
					} else {
						if (!data) {
							// delete succeeded but we got nothing back
							console.log(pendingEntries.toString());
							context.done(error, "Pending Batch Deleted but received no Return Values from Dynamo DB");
						}
					}

					var processEntries = data.Attributes.entries.SS;

					// create this batch with
					// the set of items
					var thisBatch = generateUUID();
					var processingBatch = {
						TableName : batchTable,
						Item : {
							batchId : {
								S : thisBatch
							},
							entries : {
								SS : processEntries,
							},
							lastUpdate : {
								N : '' + now(),
							},
							status : {
								S : 'pending'
							}
						}
					}
					dynamoDB.putItem(processingBatch, function(err, data) {
						if (err) {
							console.log("Unable to create pending batch with the following entries");
							console.log(processEntries);
							context.done(error, err);
						}

						processBatch(thisBatch, processEntries);
					});
				});
			} else {
				console.log("No pending batch flush required");
				context.done(null, null);
			}
		});
	}

	/* process an allocated batch */
	processBatch = function(thisBatchId, batchEntries) {
		console.log("Processing Batch " + thisBatchId);

		// create the manifest for the entries
		// create the manifest file for the file to be loaded
		var manifestContents = {
			entries : []
		};

		for (var i = 0; i < batchEntries.length; i++) {
			manifestContents.entries.push({
				url : 's3://' + batchEntries[i],
				mandatory : true
			});
		}

		createBatchManifest(thisBatchId, manifestContents);
	}

	/*
	 * function to add a file to the pending batch set and then call the success
	 * callback
	 */
	addFileEntry = function(bucket, key, successCallback) {
		var itemEntry = bucket + '/' + key;
		console.log("Adding Manifest Entry for " + itemEntry);

		// build the reference to the pending batch, with an atomic add of the
		// current file
		var item = {
			Key : {
				batchId : {
					S : pending
				}
			},
			TableName : batchTable,
			AttributeUpdates : {
				entries : {
					Action : 'ADD',
					Value : {
						SS : [ itemEntry ]
					}
				},
				lastUpdate : {
					Action : 'PUT',
					Value : {
						N : '' + now()
					}
				}
			}
		}

		dynamoDB.updateItem(item, function(err, data) {
			if (err) {
				console.log(err);
				context.done(error, err);
			}

			// call the successful callback
			if (successCallback) {
				successCallback();
			}
		});
	}

	/* function which will load redshift data from a bucket and prefix */
	createBatchManifest = function(thisBatchId, manifestContents) {
		// manifest file will be at the configuration location, with a fixed
		// prefix and the date plus a random value for uniqueness across all
		// executing functions
		var now = getFormattedDate();
		var rand = Math.floor(Math.random() * 10000);
		manifestName = 'manifest-' + now + '-' + rand;
		manifestPrefix = config.manifestKey.S + '/' + manifestName
		var s3PutParams = {
			Bucket : config.manifestBucket.S,
			Key : manifestPrefix,
			Body : JSON.stringify(manifestContents)
		};

		// save the manifest file to S3 and build the rest of the copy command
		// in the callback letting us know that the manifest was created
		// correctly
		s3.putObject(s3PutParams, loadRedshiftWithManifest.bind(undefined, thisBatchId));
	}

	/* function run when the Redshift manifest write returns */
	loadRedshiftWithManifest = function(thisBatchId, err, data) {
		if (err) {
			console.log(err);
			context.done(error, err);
		}

		/* build the redshift copy command */
		var copyCommand = '';

		// add the truncate option if requested
		if (config.truncateTarget && config.truncateTarget.BOOL) {
			copyCommand = 'truncate table ' + config.targetTable.S + ';\n';
		}

		copyCommand = copyCommand + 'begin;\nCOPY ' + config.targetTable.S + ' from \'s3://' + config.manifestBucket.S
				+ '/' + manifestPrefix + '\' with credentials as \'aws_access_key_id=' + config.accessKeyForS3.S
				+ ';aws_secret_access_key=' + config.secretKeyForS3.S + '\' manifest '

		// add data formatting directives
		if (config.dataFormat.S === 'CSV') {
			copyCommand = copyCommand + ' delimiter \'' + config.csvDelimiter.S + '\'\n';
		} else if (config.dataFormat.S === 'JSON') {
			if (config.jsonPath !== undefined) {
				copyCommand = copyCommand + 'json \'' + config.jsonPath.S + '\'\n';
			} else {
				copyCommand = copyCommand + 'json \'auto\' \n';
			}
		} else {
			context.done(error, 'Unsupported data format ' + config.dataFormat.S);
		}

		// add compression directives
		if (config.compression !== undefined) {
			copyCommand = copyCommand + ' ' + config.compression.S + '\n';
		}

		// add copy options
		if (config.copyOptions !== undefined) {
			copyCommand = copyCommand + config.copyOptions.S + '\n';
		}

		// commit
		copyCommand = copyCommand + ";\ncommit;";

		// connect to the cluster
		var clusterString = 'jdbc:postgresql://' + config.clusterEndpoint.S + ':' + config.clusterPort.N + '/'
				+ config.clusterDB.S + '?tcpKeepAlive=true';
		var dbConfig = {
			libpath : __dirname
					+ '/lib/postgresql-9.3-1102.jdbc41.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.71.x86_64/jre/lib/amd64/server/libjvm.so',
			drivername : 'org.postgresql.Driver',
			url : clusterString,
			user : config.connectUser.S,
			password : config.connectPassword.S,
		};

		console.log("Connecting to Database " + clusterString);

		/* connect to database and run the commands */
		jdbc.initialize(dbConfig, function(err, res) {
			if (err) {
				closeBatch(thisBatchId, err);
			}
		});

		jdbc.open(function(err, conn) {
			if (err) {
				closeBatch(thisBatchId, err);
			}

			if (conn) {
				jdbc.executeUpdate(copyCommand, function(err, result) {
					if (err) {
						closeBatch(thisBatchId, err);
					} else {
						console.log("Load Complete");

						// mark the batch as closed OK
						closeBatch(thisBatchId, null);
					}
				});
			} else {
				closeBatch(thisBatchId, 'Unable to Connect to Database');
			}
		});
	}

	/* close the batch to mark it as done */
	closeBatch = function(thisBatchId, batchError) {
		var batchEndStatus;

		if (batchError && batchError !== null) {
			batchEndStatus = 'error';
		} else {
			batchEndStatus = 'complete';
		}

		var item = {
			Key : {
				batchId : {
					S : thisBatchId
				}
			},
			TableName : batchTable,
			AttributeUpdates : {
				status : {
					Action : 'PUT',
					Value : {
						S : batchEndStatus
					}
				},
				lastUpdate : {
					Action : 'PUT',
					Value : {
						N : '' + now()
					}
				}
			}
		}

		// add the error message to the updates if we had one
		if (batchError && batchError !== null) {
			item.AttributeUpdates.errorMessage = {
				Action : 'PUT',
				Value : {
					S : batchError.toString()
				}
			}
		}

		// mark the batch as closed
		dynamoDB.updateItem(item, function(err, data) {
			// ugh, the batch closure didn't finish - this is not a good place
			// to be
			if (err) {
				console.log(err);
				context.done(error, err);
			}

			notify(thisBatchId, batchError);
		});
	}

	/* send SNS notifications for OK vs Failed status */
	notify = function(thisBatchId, batchError) {
		var message;
		var statusMessage = batchError ? 'error' : 'ok';
		var errorMessage = batchError ? batchError.toString() : null;
		var messageBody = {
			error : errorMessage,
			status : statusMessage,
			batchId : thisBatchId,
			manifest : config.manifestBucket.S + '/' + manifestPrefix
		}
		if (batchError && batchError !== null) {
			console.log(batchError);

			if (config.failureTopicARN) {
				message = {
					Message : JSON.stringify(messageBody),
					Subject : "Lambda Redshift Batch Load " + thisBatchId + " Failure",
					TopicArn : config.failureTopicARN.S
				}

				sns.publish(message, function(err, data) {
					if (err) {
						console.log(err);
					}
					context.done(error, batchError);
				});
			} else {
				context.done(error, batchError);
			}
		} else {
			if (config.successTopicARN) {
				message = {
					Message : JSON.stringify(messageBody),
					Subject : "Lambda Redshift Batch Load " + thisBatchId + " OK",
					TopicArn : config.successTopicARN.S
				}

				sns.publish(message, function(err, data) {
					if (err) {
						console.log(err);
					}
					context.done(error, batchError);
				});
			} else {
				console.log("Batch Load " + thisBatchId + " Complete");
				context.done(null, null);
			}
		}
	}
	/* end of runtime functions */

	// load the configuration for this prefix, which will kick off the callback
	// chain
	dynamoDB.getItem(dynamoLookup, foundConfig);
};

/* Local rubbish for CLI testing */
event = {
	"Records" : [ {
		"eventVersion" : "2.0",
		"eventSource" : "aws:s3",
		"awsRegion" : "eu-west-1",
		"eventTime" : "1970-01-01T00:00:00.000Z",
		"eventName" : "ObjectCreated:Put",
		"userIdentity" : {
			"principalId" : "AIDAJDPLRKLG7UEXAMPLE"
		},
		"requestParameters" : {
			"sourceIPAddress" : "127.0.0.1"
		},
		"responseElements" : {
			"x-amz-request-id" : "C3D13FE58DE4C810",
			"x-amz-id-2" : "FMyUVURIY8/IgAtTv8xRjskZQpcIZ9KG4V5Wp6S7S/JRWeUWerMUE5JgHvANOjpD"
		},
		"s3" : {
			"s3SchemaVersion" : "1.0",
			"configurationId" : "testConfigRule",
			"bucket" : {
				"name" : "lambda-redshift-loader-test",
				"ownerIdentity" : {
					"principalId" : "A3NL1KOZZKExample"
				},
				"arn" : "arn:aws:s3:::mybucket"
			},
			"object" : {
				"key" : "input/sample-redshift-file-for-lambda-loader2.csv",
				"size" : 1024,
				"eTag" : "d41d8cd98f00b204e9800998ecf8427e"
			}
		}
	} ]
}

function context() {}
context.done = function(status, message) {
	if (message) {
		console.log(message);
	}
	if (status !== undefined && status !== null) {
		process.exit(-1);
	} else {
		process.exit(0);
	}
}

exports.handler(event, context);